package com.nucleus.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Subject {
	
	
	@Id
private int subCode;
private String subName;
public int getSubCode() {
	return subCode;
}
public void setSubCode(int subCode) {
	this.subCode = subCode;
}
public String getSubName() {
	return subName;
}
public void setSubName(String subName) {
	this.subName = subName;
}

}
